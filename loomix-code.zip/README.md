# LOOMIX — Objects in distinction

A self-contained recreation of [loomixx.framer.website](https://loomixx.framer.website): a dark, editorial "coming soon" page for a fashion boutique, with a pinned scroll gallery, rotating phrases, live countdowns and a waitlist form.

## Run it

The site is plain HTML, CSS and JavaScript — no build step or dependencies.

```bash
cd site
python3 -m http.server 3000
```

Then open `http://localhost:3000`. Any static host (Netlify, Vercel, GitHub Pages, S3, nginx) can serve the `site/` folder as-is.

## Project structure

```
site/
  index.html            Page markup, gallery images and metadata
  css/styles.css        All layout, typography and responsive rules
  js/main.js            Countdown, phrase rotation, collage animation, starfield, form
  assets/
    img/                Fifteen campaign photographs (JPEG)
    fonts/              Self-hosted Aboreto and Raleway (woff2)
    favicon.svg
  manus-routes.json     Route manifest for the Manus preview
```

## Things you will likely want to edit

| What | Where |
| --- | --- |
| Opening date for both countdowns | `CONFIG.openingDate` at the top of `site/js/main.js` (ISO date, UTC) |
| Rotating hero phrases | `PHRASES` in `site/js/main.js` |
| Waitlist destination | `CONFIG.waitlistEndpoint` in `site/js/main.js` — set it to a Formspree, Buttondown, Mailchimp or custom `POST` URL that accepts `{ "email": "..." }` |
| Social links | The three `<a>` elements in `.site-header` in `site/index.html` |
| Contact email and copyright | `.site-footer` in `site/index.html` |
| Gallery photos and their order | `.collage` figures in `site/index.html`; the last figure is also used as the full-bleed reveal image (`#bleed`) |
| Copy, heading sizes, spacing | `site/index.html` and `site/css/styles.css` |

With no endpoint configured, the form validates the email and shows the success message locally without storing anything — useful for a design demo.

## How the scroll gallery works

The gallery section is five viewports tall. A `position: sticky` stage holds the photographs on screen while the page scrolls. `js/main.js` reads the scroll progress and:

1. scales the whole grid up from a tiny cluster,
2. pulls each photograph toward the centre with a staggered delay so the images look scattered mid-scroll,
3. shrinks a full-bleed campaign image into the last grid cell,
4. settles everything into the final 5 × 3 grid before the waitlist arrives.

On mobile the grid becomes 3 × 5 and is scaled down automatically to fit short screens. `prefers-reduced-motion` skips the animation and shows the finished grid.

## Notes

The photography and brand copy belong to LOOMIX and are included here because this is a recreation of the supplied reference site. Replace the images and copy before using the design for a different brand.
