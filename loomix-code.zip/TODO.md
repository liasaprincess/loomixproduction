# LOOMIX — Objects in Distinction

Recreation of https://loomixx.framer.website as editable, self-contained code.

## Page shell and chrome
- [x] Fixed header with a LOOMIX wordmark and Instagram, X and Facebook icon links.
- [x] Fixed footer with "© 2026 LOOMIX All rights reserved." and "im@loomix.co.uk".
- [x] Dark editorial styling throughout, using Aboreto for display type and Raleway for the wordmark/body, with self-contained local fonts and imagery.

## Hero
- [x] Full-screen hero with an oversized, faint LOOMIX wordmark behind the content.
- [x] Automatically rotating editorial phrases: "Objects in distinction", "Obsession", "Long nights", "This is what commitment looks like", "Winter 2026", with a soft blur/fade transition.
- [x] Live opening countdown (days, hours, minutes, seconds) displayed prominently in the hero.

## Scroll-driven gallery
- [x] Fifteen fashion photographs that animate from a loose cluster into an assembled 5 × 3 grid as the page scrolls, with 16 px gaps, rounded 16 px corners and soft shadows.
- [x] One full-bleed campaign image covers the viewport after the hero and shrinks into the final grid cell.
- [x] The gallery stage stays pinned during the scroll sequence and ends fully assembled before the waitlist.

## Waitlist finale
- [x] Starfield backdrop, oversized LOOMIX wordmark and the heading "Be the first to know when the doors open."
- [x] A second countdown synchronized with the hero countdown.
- [x] Responsive email signup form with the placeholder "your@email.com", a "Join the waitlist" button and the note "No spam. One email when we open."; invalid emails are rejected and valid submissions show a success message.

## Responsive and accessible
- [x] Desktop, tablet and mobile layouts keep the same composition without horizontal overflow; the collage fits the viewport at every size.
- [x] Reduced-motion preferences disable the scroll animation, starfield motion and phrase rotation.
- [x] Social links have accessible names, the email field has a label and focus states are visible.

## Delivery
- [x] README with run, edit and form-connection instructions.
- [x] Route manifest, favicon and project logo metadata.
- [x] Working preview and saved checkpoint.
