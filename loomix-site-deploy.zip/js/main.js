/* ==========================================================================
   LOOMIX — Objects in distinction
   Countdown, phrase rotation, pinned collage animation, starfield, waitlist.
   ========================================================================== */

(function () {
  "use strict";

  /* ------------------------------------------------------------------------
     Editable settings
     ------------------------------------------------------------------------ */

  var CONFIG = {
    // Opening moment used by both countdowns (UTC). Change this to your date.
    openingDate: "2026-12-15T19:00:00Z",
    // Optional POST endpoint for the waitlist (Formspree, Buttondown, your API).
    // Leave empty to run the form as a front-end demo with a success message.
    waitlistEndpoint: ""
  };

  var PHRASES = [
    "Objects in distinction",
    "Obsession",
    "Long nights",
    "This is what commitment looks like",
    "Winter 2026"
  ];

  // Per-cell entrance delays for the collage (0 = first to settle).
  var DELAYS = [
    0.55, 0.15, 0.4, 0.05, 0.3,
    0.7, 0.2, 0.5, 0.1, 0.45,
    0.35, 0.65, 0.0, 0.6, 0.25
  ];

  var prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function lerp(from, to, t) {
    return from + (to - from) * t;
  }

  function easeOutCubic(t) {
    t = clamp(t, 0, 1);
    return 1 - Math.pow(1 - t, 3);
  }

  function easeInOutCubic(t) {
    t = clamp(t, 0, 1);
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
  }

  /* ------------------------------------------------------------------------
     Countdown
     ------------------------------------------------------------------------ */

  var UNITS = [
    ["days", "Days"],
    ["hours", "Hours"],
    ["minutes", "Minutes"],
    ["seconds", "Seconds"]
  ];

  var openingTime = Date.parse(CONFIG.openingDate);

  function pad(value) {
    return value < 10 ? "0" + value : String(value);
  }

  function buildCountdowns() {
    var containers = document.querySelectorAll("[data-countdown]");

    Array.prototype.forEach.call(containers, function (container) {
      var markup = "";

      UNITS.forEach(function (unit, index) {
        if (index > 0) {
          markup +=
            '<div class="cd-sep" aria-hidden="true"><i></i><i></i></div>';
        }

        markup +=
          '<div class="cd-unit">' +
          '<span class="cd-num" data-unit="' + unit[0] + '">00</span>' +
          '<span class="cd-label">' + unit[1] + "</span>" +
          "</div>";
      });

      container.innerHTML = markup;
    });
  }

  function updateCountdown() {
    var remaining = Math.max(0, openingTime - Date.now());
    var totalSeconds = Math.floor(remaining / 1000);

    var days = Math.floor(totalSeconds / 86400);
    var hours = Math.floor((totalSeconds % 86400) / 3600);
    var minutes = Math.floor((totalSeconds % 3600) / 60);
    var seconds = totalSeconds % 60;

    var values = {
      days: days,
      hours: pad(hours),
      minutes: pad(minutes),
      seconds: pad(seconds)
    };

    UNITS.forEach(function (unit) {
      var nodes = document.querySelectorAll('[data-unit="' + unit[0] + '"]');
      Array.prototype.forEach.call(nodes, function (node) {
        if (node.textContent !== String(values[unit[0]])) {
          node.textContent = String(values[unit[0]]);
        }
      });
    });
  }

  /* ------------------------------------------------------------------------
     Rotating hero phrase
     ------------------------------------------------------------------------ */

  function initMorph() {
    var lines = document.querySelectorAll(".morph-line");
    if (!lines.length) return;

    var activeIndex = 0;
    lines[0].textContent = PHRASES[0];
    lines[0].classList.add("is-active");

    if (prefersReducedMotion) return;

    var phraseIndex = 0;

    window.setInterval(function () {
      phraseIndex = (phraseIndex + 1) % PHRASES.length;

      var outgoing = lines[activeIndex];
      var incoming = lines[1 - activeIndex];

      incoming.textContent = PHRASES[phraseIndex];
      incoming.classList.remove("is-active");

      // Flush the blurred-out state before fading the new phrase in.
      void incoming.offsetWidth;

      incoming.classList.add("is-active");
      outgoing.classList.remove("is-active");

      activeIndex = 1 - activeIndex;
    }, 3200);
  }

  /* ------------------------------------------------------------------------
     Scroll-driven collage
     ------------------------------------------------------------------------ */

  function initGallery() {
    var gallery = document.getElementById("gallery");
    var stage = document.getElementById("stage");
    var collage = document.getElementById("collage");
    var bleed = document.getElementById("bleed");
    var shade = document.getElementById("hero-shade");

    if (!gallery || !stage || !collage || !bleed) return;

    var cells = Array.prototype.slice.call(collage.children);
    var cellData = [];
    var cellStates = [];
    var vw = 0;
    var vh = 0;
    var gridW = 0;
    var gridH = 0;
    var fit = 1;
    var centerX = 0;
    var centerY = 0;

    function measure() {
      vw = stage.clientWidth;
      vh = stage.clientHeight;
      gridW = collage.offsetWidth;
      gridH = collage.offsetHeight;

      cellData = cells.map(function (cell) {
        return {
          x: cell.offsetLeft,
          y: cell.offsetTop,
          w: cell.offsetWidth,
          h: cell.offsetHeight
        };
      });

      centerX = gridW / 2;
      centerY = gridH / 2;

      var headerHeight =
        parseFloat(getComputedStyle(document.documentElement).getPropertyValue("--header-h")) || 88;
      var reserve = headerHeight * 2 + 32;

      // Keep the finished collage inside the stage on short or narrow screens.
      fit = Math.min(1, (vh - reserve) / gridH, (vw * 0.94) / gridW);

      // The first measurement can happen before layout settles; never cache NaN.
      if (!isFinite(fit) || fit <= 0) fit = 0.35;
    }

    function render() {
      var rect = gallery.getBoundingClientRect();
      var total = gallery.offsetHeight - vh;
      var scrolled = clamp(-rect.top, 0, total);
      var progress = total > 0 ? scrolled / total : 1;

      if (prefersReducedMotion) progress = 1;

      var scaleProgress = easeInOutCubic(clamp((progress - 0.04) / 0.65, 0, 1));
      var scale = fit * scaleProgress;

      collage.style.opacity = prefersReducedMotion ? "1" : String(clamp(progress / 0.06, 0, 1));
      collage.style.transform = "scale(" + scale + ")";

      // Darken the reveal while the hero is still on screen, then fade away.
      if (shade) {
        shade.style.opacity = prefersReducedMotion
          ? "0"
          : String(1 - clamp(-rect.top / vh, 0, 1));
      }

      for (var i = 0; i < cells.length; i += 1) {
        var data = cellData[i];
        var delay = DELAYS[i] || 0;
        var q = easeOutCubic(clamp((progress - 0.12 - delay * 0.4) / 0.55, 0, 1));

        var pull = (1 - q) * 0.65;
        var dx = (centerX - (data.x + data.w / 2)) * pull;
        var dy = (centerY - (data.y + data.h / 2)) * pull;
        var cellScale = 0.55 + 0.45 * q;

        cellStates[i] = { dx: dx, dy: dy, scale: cellScale, q: q };

        if (prefersReducedMotion) {
          cells[i].style.transform = "none";
        } else {
          cells[i].style.transform =
            "translate(" + dx.toFixed(2) + "px, " + dy.toFixed(2) + "px) scale(" +
            cellScale.toFixed(4) + ")";
        }
      }

      // The full-bleed image dissolves into the final grid cell.
      if (prefersReducedMotion) {
        bleed.style.opacity = "0";
        return;
      }

      var last = cellData[cellData.length - 1];
      var lastState = cellStates[cellStates.length - 1] || { dx: 0, dy: 0, scale: 1 };
      var land = easeInOutCubic(clamp((progress - 0.18) / 0.32, 0, 1));

      var targetCenterX = vw / 2 + (last.x + last.w / 2 - centerX + lastState.dx) * scale;
      var targetCenterY = vh / 2 + (last.y + last.h / 2 - centerY + lastState.dy) * scale;
      var targetW = last.w * scale * lastState.scale;
      var targetH = last.h * scale * lastState.scale;

      var left = (targetCenterX - targetW / 2) * land;
      var top = (targetCenterY - targetH / 2) * land;
      var width = lerp(vw, targetW, land);
      var height = lerp(vh, targetH, land);

      bleed.style.left = left.toFixed(2) + "px";
      bleed.style.top = top.toFixed(2) + "px";
      bleed.style.width = width.toFixed(2) + "px";
      bleed.style.height = height.toFixed(2) + "px";
      bleed.style.borderRadius = (16 * land).toFixed(2) + "px";

      var fadeIn = clamp((progress - 0.015) / 0.05, 0, 1);
      var fadeOut = 1 - clamp((progress - 0.4) / 0.1, 0, 1);
      bleed.style.opacity = String(Math.min(fadeIn, fadeOut));
    }

    var ticking = false;

    function onScroll() {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(function () {
        ticking = false;
        render();
      });
    }

    function onResize() {
      window.requestAnimationFrame(function () {
        measure();
        render();
      });
    }

    measure();
    render();

    // Re-measure once layout, images and fonts have had a frame to settle.
    window.requestAnimationFrame(function () {
      measure();
      render();
    });
    window.addEventListener("load", onResize);

    if (!prefersReducedMotion) {
      window.addEventListener("scroll", onScroll, { passive: true });
    }

    window.addEventListener("resize", onResize);

    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(function () {
        measure();
        render();
      });
    }
  }

  /* ------------------------------------------------------------------------
     Waitlist starfield
     ------------------------------------------------------------------------ */

  function mulberry32(seed) {
    return function () {
      seed |= 0;
      seed = (seed + 0x6d2b79f5) | 0;
      var t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  function initStarfield() {
    var canvas = document.getElementById("starfield");
    var section = document.getElementById("waitlist");

    if (!canvas || !section || !canvas.getContext) return;

    var ctx = canvas.getContext("2d");
    var stars = [];
    var width = 0;
    var height = 0;
    var dpr = 1;
    var rafId = 0;
    var running = false;
    var started = performance.now();
    var random = mulberry32(0x10c0ffee);

    function resize() {
      var rect = section.getBoundingClientRect();
      width = Math.max(1, Math.round(rect.width));
      height = Math.max(1, Math.round(rect.height));
      dpr = Math.min(2, window.devicePixelRatio || 1);

      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      canvas.style.width = width + "px";
      canvas.style.height = height + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      var count = Math.round((width * height) / 2100);
      stars = [];

      for (var i = 0; i < count; i += 1) {
        var kind = random();
        var size = kind > 0.92 ? 1.8 + random() * 1.2 : kind > 0.6 ? 1 + random() * 0.6 : 0.55 + random() * 0.45;

        stars.push({
          x: random() * width,
          y: random() * height,
          size: size,
          base: 0.22 + random() * 0.65,
          twinkle: 0.35 + random() * 1.5,
          phase: random() * Math.PI * 2,
          drift: 0.15 + random() * 0.6,
          speed: 1.2 + random() * 4.2
        });
      }
    }

    function draw(now) {
      var t = (now - started) / 1000;
      ctx.clearRect(0, 0, width, height);

      for (var i = 0; i < stars.length; i += 1) {
        var star = stars[i];
        var wrapped = ((star.y - t * star.speed) % (height + 20) + (height + 20)) % (height + 20) - 10;
        var x = star.x + Math.sin(t * star.drift + star.phase) * 5;
        var alpha = star.base * (0.55 + 0.45 * Math.sin(t * star.twinkle + star.phase));
        alpha = clamp(alpha, 0, 1);

        ctx.fillStyle = "rgba(255, 255, 255, " + alpha.toFixed(3) + ")";

        if (star.size > 1.4) {
          ctx.shadowColor = "rgba(255, 255, 255, 0.65)";
          ctx.shadowBlur = 5;
        } else {
          ctx.shadowBlur = 0;
        }

        ctx.beginPath();
        ctx.arc(x, wrapped, star.size / 2, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.shadowBlur = 0;
    }

    function loop(now) {
      draw(now);
      rafId = window.requestAnimationFrame(loop);
    }

    function start() {
      if (running) return;
      running = true;

      if (prefersReducedMotion) {
        draw(performance.now());
        return;
      }

      rafId = window.requestAnimationFrame(loop);
    }

    function stop() {
      running = false;
      window.cancelAnimationFrame(rafId);
    }

    resize();

    if (prefersReducedMotion) {
      draw(performance.now());
    }

    if ("IntersectionObserver" in window) {
      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              start();
            } else {
              stop();
            }
          });
        },
        { threshold: 0.02 }
      );

      observer.observe(section);
    } else {
      start();
    }

    window.addEventListener("resize", function () {
      resize();
      if (!running || prefersReducedMotion) draw(performance.now());
    });
  }

  /* ------------------------------------------------------------------------
     Waitlist form
     ------------------------------------------------------------------------ */

  function initForm() {
    var form = document.getElementById("waitlist-form");
    var input = document.getElementById("email");
    var note = document.getElementById("form-note");
    var status = document.getElementById("form-status");

    if (!form || !input || !note || !status) return;

    var button = form.querySelector("button");
    var originalLabel = button ? button.textContent : "Join the waitlist";

    input.addEventListener("input", function () {
      input.removeAttribute("aria-invalid");
      status.classList.remove("is-visible");
      status.textContent = "";
    });

    form.addEventListener("submit", function (event) {
      event.preventDefault();

      var email = input.value.trim();

      if (!email || !input.checkValidity()) {
        input.setAttribute("aria-invalid", "true");
        status.textContent = "Please enter a valid email address.";
        status.classList.add("is-visible");
        input.focus();
        return;
      }

      input.removeAttribute("aria-invalid");
      status.classList.remove("is-visible");
      status.textContent = "";

      if (button) {
        button.disabled = true;
        button.textContent = "Joining…";
      }

      var request;

      if (CONFIG.waitlistEndpoint) {
        request = fetch(CONFIG.waitlistEndpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ email: email })
        }).then(function (response) {
          if (!response.ok) throw new Error("Waitlist request failed");
        });
      } else {
        request = new Promise(function (resolve) {
          window.setTimeout(resolve, 650);
        });
      }

      request
        .then(function () {
          form.hidden = true;
          note.hidden = true;
          status.textContent = "You're on the list. We'll write when the doors open.";
          status.classList.add("is-visible");
        })
        .catch(function () {
          if (button) {
            button.disabled = false;
            button.textContent = originalLabel;
          }
          status.textContent = "Something went wrong. Please try again.";
          status.classList.add("is-visible");
        });
    });
  }

  /* ------------------------------------------------------------------------
     Boot
     ------------------------------------------------------------------------ */

  buildCountdowns();
  updateCountdown();
  window.setInterval(updateCountdown, 1000);

  initMorph();
  initGallery();
  initStarfield();
  initForm();
})();
